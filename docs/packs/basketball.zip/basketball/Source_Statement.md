## Question 1 of APOAI2025 Mock Competition: Predicting the Shooting Percentage of Basketball Stars

**Introduction**:  This is the Question 1 of APOAI2025 Mock Competition, and it is also the first question of the NOAI2024(China).
### I. Question Overview

A CSV file of basketball stars' shooting data is given, which is stored in the training set "data_train.csv".
The meaningful variables are named as follows:

- **loc_x**: The horizontal position of the basketball star on the court when shooting, which has been normalized. There is no need to consider the unit.
- **loc_y**: The vertical position of the basketball star on the court when shooting, which has been normalized. There is no need to consider the unit.
- **minutes_remaining**: The number of minutes remaining in the current quarter, which has been normalized. There is no need to consider the unit.
- **shot_distance**: The distance from the shooting position to the basket, which has been normalized. There is no need to consider the unit.
- **shot_made_flag**: Whether the shot is made or not. If it is made, the value is 1, otherwise, the value is 0.
- **shot_id**: The unique identifier of the sample.

Now, it is hoped that you can build a model based on the historical data of the basketball star to predict the shooting result of the star. There are 20,000 data points in the training set, and the test set has approximately 5,000 data points. The format is similar to that of the training set, and the contestants cannot access it during the competition.

### II. Data Set

**Address of the training set**: [Training Set](https://bohrium.dp.tech/competitions/5135119121?tab=datasets)

### III. Task

Please use PyTorch to implement a multi-layer perceptron (neural network) model to predict whether a contestant can make a shot at different positions.
The specific requirements are as follows:

1. The input consists of 2 features (loc_x, loc_y), and the output is 1 label (shot_made_flag). 1 indicates that the shot is made, and 0 indicates that the shot is missed.
2. Only linear layers and activation functions after linear layers can be used, and at most 3 linear layers can be used. Please build the neural network directly and do not use nn.sequential() nesting. The scoring system cannot detect the network structure inside nn.sequential(), and a score of 0 will be directly given.
3. The activation function can only be selected from nn.Linear, nn.ReLU, nn.Sigmoid, nn.Tanh, nn.ELU, nn.LeakyReLU, nn.PreLU.
4. Each linear layer can have at most 8 neurons.
5. The loss function (Loss Function), optimizer (Solver), and learning rate (Learning Rate) can be freely selected.

### IV. Submission

Please submit a compressed file named submission.zip. After decompression, it should contain the model file submission_model.py and the model parameter file submission_dic.pth. The specific requirements are as follows:

1. Save the class definition of the model and the required precursor libraries in submission_model.py.
2. Save the trained model parameters in submission_dic.pth. The model parameters will be loaded during scoring.
3. You can refer to the method in baseline.ipynb to generate the submission.zip file on the platform for submission. You can also download the data set to the local machine, train the model, and then package it into a submission.zip file for submission.

**Address of baseline.ipynb**: [Question 1 of APOAI2025 Mock Competition_baseline](https://bohrium.dp.tech/notebooks/18211783382)


### V. Scoring

1. When the number of linear layers and the number of neurons in the neural network meet the requirements, the score is the accuracy rate of the test set.
2. When the number of linear layers and the number of neurons in the neural network do not meet the requirements, the score is 0.

**Remarks**: The leaderboard A uses 50% of the data in the test set, which can be displayed in real time during the competition to help contestants debug the model. The leaderboard B uses the remaining 50% of the data in the test set and is calculated after the competition ends. The score of the leaderboard B is the final score. 

